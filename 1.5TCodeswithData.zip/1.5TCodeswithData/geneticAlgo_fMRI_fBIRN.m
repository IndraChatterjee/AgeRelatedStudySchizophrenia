function [chromeSet,chromeAcc]=geneticAlgo_fMRI_fBIRN(trainVect1,ind,FullData,lab,accIni,popSize)
%Genetic Algorithm for fMRI data
% clear all;
% load('DataNeededforGA.mat'); %Load only necessary matrix files
%after raw data loading and ttest and chromosome generation.

trainVect300New=trainVect1; %initialization with random chromosome
accSibNew=[];
finalChromeCell=cell(1,2);

for iter=1:100
    [Vect300Sel,tourSelIndex,accSel]=tourSelectionFunc(trainVect300New,accIni); %To run 2phase tournament for selection of each chromosome
    [Vect300Cross,crossVectInd]=crossoverFunc(Vect300Sel); %To perform single point crossover
%     crossAcc=fitnessValFunc(Vect300Cross,FullData,lab,ind); %checking fitness func after crossover
%     [crossAccNew,Vect300CrossNew]=checkCrossSel(accSel,crossAcc,crossVectInd,Vect300Cross,Vect300Sel); %check to see the better offspring, crossed/prev selected
%     disp('finished crossover')
    Vect300Mute=mutationFunc(Vect300Cross); %Apply mutation to each chromosome
    muteAcc=fitnessValFunc(Vect300Mute,FullData,lab,ind); %finding fitness func after mutation
    [muteAccNew,Vect300MuteNew,featVectInd]=checkMuteCross(muteAcc,accSel,Vect300Sel,Vect300Mute); %check to see the better offspring, muted/prev crossed
    %muteAccNew stores the each chrome acc and their no of features(1's)
    %Vect300MuteNew stores the final set of popSizexDim chromosome set
    %featVectInd stores the index of selected features from each chromosome
%     disp('finished mutation')
    trainVect300New=Vect300MuteNew;
    accSibNew=muteAccNew;
    
%     maxAcc300=find(muteAccNew==(max(muteAccNew(:,1)))); %finding the maximum acc and their index of chromosome from 400 chromosoe
% 
%     bestVect300=trainVect300New(maxAcc300(:,1),:); %storing only the chromosomes having best acc
    
 
%     finalChromeCell(iter,1)={Vect300MuteNew}; %final 400 set of chromosomes for each iteration
%     finalChromeCell(iter,2)={muteAccNew}; %final Accuracy for 400vector for each iteration
%     finalChromeCell(iter,3)={maxAcc300}; %max Acc and only their index out 400vector for each iteration
%     finalChromeCell(iter,4)={featVectInd}; %storing maximum acc among popSize
%     finalChromeCell(iter,5)={bestVect300}; %storing only best set of chromosome with best accuracy
%     clear maxAcc300 bestVect300;
%     iter
end
finalChromeCell(1,1)={trainVect300New};
finalChromeCell(1,2)={accSibNew};
[chromeSet,chromeAcc]=postAnalysis60_2_300_code1(finalChromeCell,popSize);
% finalGAChrome1_100_300(1,1)={chromeSet};
% finalGAChrome1_100_300(1,2)={chromeAcc};
end

