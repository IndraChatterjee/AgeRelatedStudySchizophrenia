function res= FitnessFuncSVM(temp,X,lab)
%function to calculate fitness function through SVM classifier for
%each vectors

[ind]=crossvalind('Kfold',60,60);
% Vector of 10 val for 60-fold Cross validation same as LOOCV
for i=1:60
    s=sum(temp(1,:));    % count frequency of 1 in each chrome
    Xtrain=X(setdiff([1:60],ind(i)),temp);  %fulldata Matrix instance used in prev ttest particular iteration
    %features from chrome which has 1
    labtrain=lab(setdiff([1:60],ind(i)),:);   %Label from training data used in particular iteration of ttest/
    Xtest=X(ind(i),temp);
    labtest=lab(ind(i),:);
    
    model = svmtrain(double(labtrain),double(Xtrain),'-q');
    predlab = svmpredict(double(labtest), double(Xtest),model,'-q');
    
    if(labtest == predlab)
        acc(i)=100;
    else
        acc(i)=0;
    end
    
end
res=mean(acc);
end