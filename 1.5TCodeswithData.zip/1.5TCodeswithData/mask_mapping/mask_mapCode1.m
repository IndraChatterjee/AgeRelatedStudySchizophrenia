I=load_nii('mask_template/healthy01.img'); % 53*63*46
I.img=zeros(size(I.img));
I1=I.img;
c=find(chromeSetRealVox1(:,:)~=0);
VoxInd=chromeSetRealVox1(c);
VoxInd1=unique(VoxInd);
I1(VoxInd)=T(VoxInd); %any ttest results
I.img=I1;

save_nii(I,'result/GA_maskttest.img'); % 53*63*46

%% coordinate XYZ finding for value=10 in 53*63*46

[x y z] = ind2sub(size(I1),find(I1~=0));
coords = [x y z];
%coregistered H1_r1_con1.img(source) with T1.img(Reference)
V=spm_vol('mask_template/rT1.nii'); %rT1.nii is the result of coregistration
%T = Rotational Matrix needed for cor2mni.m.
T = V.mat; %(it will give in millimeter coordinate XYZ (+/-))

mni=cor2mni(coords,T);

tal=mni2tal(mni);

% Co-regisrtation of GA_mask (source) with T1 (refe)->rGA_mask (91*109*91)
