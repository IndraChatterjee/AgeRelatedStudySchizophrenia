%% Calculating Uniqueness and their frequency Count for each category in each Atlas

result1=csv2cell('talCoord.td.csv','fromfile');
% hemisphere
hem1=result1(2:394,5);
hem1{1,2}=unique(hem1(:,1));

for i=1:size(hem1{1,2},1)
    hem1{1,2}{i,2}=sum(sum(ismember(result1(2:394,5),num2str(hem1{1,2}{i,1}))));
end

% Lobes
lobe1=result1(2:394,6);
lobe1{1,2}=unique(lobe1(:,1));

for i=1:size(lobe1{1,2},1)
    lobe1{1,2}{i,2}=sum(sum(ismember(result1(2:394,6),lobe1{1,2}{i,1})));
end

% Gyrus
gyrus1=result1(2:394,7);
gyrus1{1,2}=unique(gyrus1(:,1));

for i=1:size(gyrus1{1,2},1)
    gyrus1{1,2}{i,2}=sum(sum(ismember(result1(2:394,7),gyrus1{1,2}{i,1})));
end

% CellType Brodmann
brodman1=result1(2:394,9);
brodman1{1,2}=unique(brodman1(:,1));

for i=1:size(brodman1{1,2},1)
    brodman1{1,2}{i,2}=sum(sum(ismember(result1(2:394,9),brodman1{1,2}{i,1})));
end