
%% fetching real voxel vals into final top1 chromeSet for each ttest iteration
cell1=FinalCellAlgoRun1{1,1}{1,1};
arr1=lookupArrayRun1{1,1};
for i=1:28
    tempInd=find(cell1(i,:)==1);
%     chromeSetVox=cellFinalChrome(i,:);
    chromeSetRealVox1(i,tempInd)=arr1(i,tempInd);
end


%% experiment 2 to count the Total accuracy from each final sel chromosome after 100th GA for each 60 model
%with same indCV index
% for i=1:60
%     temp1=cellFinalChrome(i,:); %final GA o/p best chromosome for each model set
%     tempInd=find(temp1==1);
%     FeatSetRealVox=lookupArray(i,tempInd); %fetching their real voxel index
%     %ans is used to check our algo can work or not for same testset which
%     %it is giving 100% earlier
%     [res,ans]=FitnessFuncSVM(FeatSetRealVox,X,lab,indCV(i)); %measuring accuracy with LOOCV for each chrome
% answer(i,1)=ans;   
%     Expt1Accuracy(i,1)=res; %storing LOOCV accuracy for each chrome
% %     i
% end
% finalAccuracyExpt1=mean(Expt1Accuracy);


%% fetching real voxel vals into final top1 chromeSet for each ttest iteration
% for i=1:60
%     tempInd=find(cellFinalChrome(i,:)==1);
% %     chromeSetVox=cellFinalChrome(i,:);
%     chromeSetRealVox(i,tempInd)=lookupArray(i,tempInd);
% end
% 
% %check Histogram or frequency count of each voxels
% a = unique(chromeSetRealVox);
% out = [a,histc(chromeSetRealVox(:),a)];

% %classification with SVM
% [ind]=crossvalind('Kfold',60,60);
% % Vector of 10 val for 60-fold Cross validation same as LOOCV
% for i=1:60
%     Xtrain=FullData(setdiff([1:60],ind(i)),tempInd);  %fulldata Matrix instance used in prev ttest particular iteration
%     %features from chrome which has 1
%     labtrain=lab(setdiff([1:60],ind(i)),:);   %Label from training data used in particular iteration of ttest/
%     Xtest=FullData(ind(i),tempInd);
%     labtest=lab(ind(i),:);
%
%     model = svmtrain(double(labtrain),double(Xtrain),'-q');
%     predlab = svmpredict(double(labtest), double(Xtest),model,'-q');
%
%     if(labtest == predlab)
%         acc=100;
%     else
%         acc=0;
%     end
% end

