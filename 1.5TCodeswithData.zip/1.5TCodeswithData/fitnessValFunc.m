function f=fitnessValFunc(trainVect,FullData,lab,index)
% tic
popSize=size(trainVect,1);
for i=1:popSize
    temp=trainVect(i,:); %fetching each chromosome
    accCross(i,:)=FitnessFuncSVMloocv(temp,FullData,lab,index);  %checking its accuracy by SVM by LOOCV 
end
% toc
% clearvars -except 
f=accCross;
end
