function [tour,idx,accNew]= tourSelectionFunc(trainVect300,acc)
%function to run 2phase tournament for selection of chromosome

ind1=1;         %index to count the final selected pool
popSize=size(trainVect300,1);    %population size(no of chromosome)
for phase=1:2       %each chromosome will play twice with each other
    list1=1:popSize;        %creating a list to maintain unused index
    for i=1:round(popSize/2)    %half the popsize becoz of each player will play once for each participation
        ind2=size(list1,2);     %index to count current size of list
        j1=randi([1,ind2]);     %randomly taking a no within the list size range
        a1=list1(j1);           %choosing that value of the index
        list1(j1)=[];           %reducing list by deleting the used index
        ind2=ind2-1;
        j2=randi([1,ind2]);
        a2=list1(j2);
        list1(j2)=[];
        %MultiObjective testing for selection
        if(acc(a1,1)>=acc(a2,1) && acc(a1,2)<=acc(a2,2)) %checking the finess function whether acc is more and feature is less
            trainVect300Sel(ind1,:)=trainVect300(a1,:); %storing the winner
            VectCount(ind1,1)=a1; %list the chrome no which one won
        elseif (acc(a1,1)<=acc(a2,1) && acc(a1,2)<=acc(a2,2))
            trainVect300Sel(ind1,:)=trainVect300(a2,:); %give priority to accuracy of second chrome
            VectCount(ind1,1)=a2;
        elseif (acc(a1,1)>=acc(a2,1) && acc(a1,2)>=acc(a2,2))
            trainVect300Sel(ind1,:)=trainVect300(a1,:); %give priority to accuracy of first chrome
            VectCount(ind1,1)=a1;            
        else
            trainVect300Sel(ind1,:)=trainVect300(a2,:); %take second chrome
            VectCount(ind1,1)=a2;
        end
        ind1=ind1+1;
        ind2=ind2-1;
    end
end
tour=trainVect300Sel;
idx=VectCount;
for i=1:popSize
    accNew(i,1)=acc(VectCount(i,1),1);
    accNew(i,2)=acc(VectCount(i,1),2);
end
end