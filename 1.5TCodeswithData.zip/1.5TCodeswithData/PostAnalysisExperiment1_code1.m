%% experiment 2 to count the Total accuracy from each final sel chromosome after 100th GA for each 60 model
for i=1:60
    temp1=cellFinalChrome(i,:); %final GA o/p best chromosome for each model set
    tempInd=find(temp1==1);
    FeatSetRealVox=lookupArray(i,tempInd); %fetching their real voxel index
    res=FitnessFuncSVM(FeatSetRealVox,X,lab); %measuring accuracy with LOOCV for each chrome
    Expt1Accuracy(i,1)=res; %storing LOOCV accuracy for each chrome
    i
end
finalAccuracyExpt1=mean(Expt1Accuracy);