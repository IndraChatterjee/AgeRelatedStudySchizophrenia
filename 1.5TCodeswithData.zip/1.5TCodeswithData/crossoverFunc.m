function [cr,crossVectInd]=crossoverFunc(trainVect300Sel)
%function to do crossover of each chromosome
ind1=1;     %index to count the final selected pool
popSize=size(trainVect300Sel,1);    %population size(no of chromosome)
list1=1:popSize;
for i=1:round(popSize/2)
    ind2=size(list1,2);
    j1=randi([1,ind2]);
    tempArr1=trainVect300Sel(list1(j1),:); %fetching the vector from list index
    list1(j1)=[];
    ind2=ind2-1;
    j2=randi([1,ind2]);
    tempArr2=trainVect300Sel(list1(j2),:);
    list1(j2)=[];
    crossInd(i,1)=j1;
    crossInd(i,2)=j2;
    cutPt=randi([2,size(trainVect300Sel,2)-1]); %randomly generating single crossover point
    tempArr1c=[tempArr1(1,1:cutPt) tempArr2(1,cutPt+1:end)]; %crossing over
    tempArr2c=[tempArr2(1,1:cutPt) tempArr1(1,cutPt+1:end)]; % AB/CD=AD/CB
    %ENTERING INTO Cross pool
    trainVect300Cross(ind1,:)=tempArr1c;
    trainVect300Cross(ind1+1,:)=tempArr2c;
    ind1=ind1+2;
    ind2=ind2-1;
end
% end
cr=trainVect300Cross;
crossVectInd=crossInd;
end

