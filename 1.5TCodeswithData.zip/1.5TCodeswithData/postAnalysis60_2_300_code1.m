function [cellFinalChrome,cellFinalAcc]=postAnalysis60_2_300_code1(finalChromeCell,popSize)

%% to extract a single chrome having max acc and min feat_count for each model
% for i=1:60
%     ind=0;
k=1;
temp1=[];
tempChrome=finalChromeCell{1,1};
tempAcc=finalChromeCell{1,2};

for j=1:popSize
    if(tempAcc(j,1)==100) %storing the values with max accuracy
        temp1(k,:)=tempAcc(j,:);
        k=k+1;
    end
end
if (isempty(temp1)) %if there is any chromeset whose all acc are 0%
    cellFinalChrome=0;
    cellFinalAcc=0;
else
    no=min(temp1(:,2)); % finding minimum featSet from max accuracy set
    for j=1:popSize
        if(tempAcc(j,1)==100 && tempAcc(j,2)==no)
            ind=j; %finding its index and storing it to fetch the chromosome only
        end
    end
    cellFinalChrome=tempChrome(ind,:);
    cellFinalAcc=tempAcc(ind,:);
end
% temp1=[];
% end
end

%% find the total experiment accuracy out 0f 10runs after post analysis of 10runs
% for i=1:10
% num=find((FinalCellAlgoRun1{1,1}{1,2})==100);
% s=size(num,1);
% run=s/44;
% end
% runAcc=mean(run);
