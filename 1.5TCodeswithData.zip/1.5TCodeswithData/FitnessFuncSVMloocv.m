function res= FitnessFuncSVMloocv(temp,FullData,lab,index)
%leave one out cross validation

% [ind]=crossvalind('Kfold',60,60);
% Vector of 10 val for 60-fold Cross validation same as LOOCV
% for i=1:60
    s=sum(temp(1,:));    % count frequency of 1 in each chrome
    tempInd=find(temp(1,:)==1);
    Xtrain=FullData(setdiff([1:44],index),tempInd);  %fulldata Matrix instance used in prev ttest particular iteration
    %features from chrome which has 1
    labtrain=lab(setdiff([1:44],index),:);   %Label from training data used in particular iteration of ttest/
    Xtest=FullData(index,tempInd);
    labtest=lab(index,:);
    
    model = svmtrain(double(labtrain),double(Xtrain),'-t 0');
    predlab = svmpredict(double(labtest), double(Xtest),model,'-q');
    
    if(labtest == predlab)
        acc=100;
    else
        acc=0;
    end
    accIni(1,1)=acc;                      %storing accuracy
    accIni(1,2)=s;
% end
res=accIni;
end