function mute= mutationFunc(trainVect300Cross)
%function to carry out mutation of each chromosome

popSize=size(trainVect300Cross,1);
dimSize=size(trainVect300Cross,2);
trainVect300Mutate=zeros(popSize,dimSize);
for i=1:popSize
    temp=trainVect300Cross(i,:);
    s=size(temp,2);
    cutPtMute=round(1+(s-1).*rand(1,3)); %random mutate point
    %to check whether point is in 1st or last index
    %so that to put new val as a value b/w two neighbor
    for j=1:3  %3 cutpoints as Mutation rate taken=0.001 %
        if(temp(1,cutPtMute(j))==0)
            temp(1,cutPtMute(j))=1;
        else
            temp(1,cutPtMute(j))=0;
        end
        trainVect300Mutate(i,:)=temp;
    end
    mute=trainVect300Mutate;
end
