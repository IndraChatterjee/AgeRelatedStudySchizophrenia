function [finalGA44_1]=data_svm_300_600Chromosome1(lookupArray,xh,xs,indCV)
%% SVM for classifying the correct label b/w predicted and true class to find the schizophrenic patient
%% 300 size vector creation having 20% (1) and 80% (0)
% clear all;
% load('ttestResult60loocv_run2.mat');
% finalGAChrome1_100_300=cell(60,1);
finalGA44_1=cell(1,2);
popSize=200;
lab(1:30,1)=1;              %labelling the label vector
lab(31:44,1)=2;

for iteration=1:44
    NewX = xh(:, lookupArray(iteration,:)); %selecting those val from contrast img for index which has been ranked acc to Tvalues for highest significant voxels.
    NewY = xs(:, lookupArray(iteration,:));
    FullData= [NewX;NewY];
    
    for i=1:popSize
        trainVect1(i,:)=rand(1,300);       %randonly taking 300 nos between 0&1
        for j=1:300
            if(trainVect1(i,j)>0.2)
                trainVect1(i,j)=0;      %to take 80 % zeros
            else
                trainVect1(i,j)=1;      %to take 2% ones
            end
        end
    end
    %%taking the train & test set from prev ttest CV result
    %classification
    for i=1:popSize
        s=sum(trainVect1(i,:));    % count frequency of 1 in each chrome
        tempInd=find(trainVect1(i,:)==1);
        Xtrain=FullData(setdiff([1:44],indCV(iteration)),tempInd);  %fulldata Matrix instance used in prev ttest particular iteration
        %features from chrome which has 1
        labtrain=lab(setdiff([1:44],indCV(iteration)),:);   %Label from training data used in particular iteration of ttest/
        Xtest=FullData(indCV(iteration),tempInd);
        labtest=lab(indCV(iteration),:);
        
        model = svmtrain(double(labtrain),double(Xtrain),'-t 0');
        predlab = svmpredict(double(labtest), double(Xtest),model,'-q');
        
        if(labtest == predlab)
            acc=100;
        else
            acc=0;
        end
        accIni(i,1)=acc;                      %storing accuracy
        accIni(i,2)=s;
    end
    ind=indCV(iteration);
    [chromeSet,chromeAcc]=geneticAlgo_fMRI_fBIRN(trainVect1,ind,FullData,lab,accIni,popSize);
    finalGAChromeSet(iteration,:)=chromeSet;
    finalGAChromeAcc(iteration,:)=chromeAcc;
%     chromeSet,chromeAcc
    %     finalGAChrome60_100_300(iteration,1)={finalGAChrome1_2_300};
    %     disp('iteration')
%     iteration
end
finalGA44_1(1,1)={finalGAChromeSet};
finalGA44_1(1,2)={finalGAChromeAcc};
% save('finalGAChrome60_2_300_run2.mat','finalGAChrome60_100_300','-v7.3');
end









