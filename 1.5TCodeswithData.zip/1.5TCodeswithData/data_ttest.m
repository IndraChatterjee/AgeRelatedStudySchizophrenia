

X=[xh;xs]; %compiling full data for healthy and schz
[m1,n1]=size(X);
%% Paired Student T-Test
H=[];
T=[];
indx=[];
NewX=[];
NewY=[];
% size of row(no .of subject)

[ind]=crossvalind('Kfold',60,60);
for i=1:1
    for j=1:n1
        % size of column(no. of voxels)
        % ttest for finding significance level b/w healthy and schz patient
        %     [h,p,a,stat]=ttest2(X(1:30,j), X(31:60,j));
        %     H(j)=h;                              % hypothesis matrix
        %     T(j)= abs(stat.tstat);               % tstat values
        
        if(ind(i)<=30)
            [h,p,a,stat]=ttest2(X(setdiff([1:30],ind(i)),j), X(31:60,j));
        else
            [h,p,a,stat]=ttest2(X(1:30,j), X(setdiff([31:60],ind(i)),j));
        end
        H(j)=h;                              % hypothesis matrix
        T(j)= abs(stat.tstat);
    end
end

FeatSel=find(H==1);    %finding the index of those voxels among 153594 vox whose null hypo has been rejected.
FeatSelNew1 = T(FeatSel);  %getting the T-values for those index whose H=1
[FeatSelNew,indx] = sort(FeatSelNew1, 'descend'); %sorting in descndng order,for Ranking the T-values to get there index

NewX = xh(:, FeatSel(indx(1:300))); %selecting those val from contrast img for index which has been ranked acc to Tvalues for highest significant voxels.
NewY = xs(:, FeatSel(indx(1:300))); % ''

FullData= [NewX;NewY];