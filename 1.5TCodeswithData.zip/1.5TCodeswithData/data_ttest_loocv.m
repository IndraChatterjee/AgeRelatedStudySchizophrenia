
clear all;
load 'data15TAllyoung.mat';
X=data15TAllYoung;
% X=[xh_jun;xs_jun]; %compiling full data for healthy and schz
[m1,n1]=size(X);
xh=double(X(1:30,:));
xs=double(X(31:44,:));
%% 1 run for each 44 model of ttest, chromecreation and GA
FinalCellAlgoRun1=cell(1,1);
lookupArrayRun1=cell(1,1);
for run=1:1
    %Paired Student T-Test
    H=zeros(44,n1);  %%dataset1 44=14+14
    T=zeros(44,n1);   
    
    % size of row(no .of subject)
    [indCV]=1:44;
    for i=1:44
%         for j=1:n1
            % size of column(no. of voxels)
            % ttest for finding significance level b/w healthy and schz patient
            if(indCV(i)<=30)
                [h,p,a,stat]=ttest2(X(setdiff([1:30],indCV(i)),:), X(31:44,:));
            else
                [h,p,a,stat]=ttest2(X(1:30,:), X(setdiff([31:44],indCV(i)),:));
            end
            H=h;                              % hypothesis matrix
            T= abs(stat.tstat);               % tstat values
%         end
        %end
        
        FeatSel=find(H==1);    %finding the index of those voxels among 153594 vox whose null hypo has been rejected.
        FeatSelNew1 = T(FeatSel);  %getting the T-values for those index whose H=1
        [FeatSelNew,indx] = sort(FeatSelNew1, 'descend'); %sorting in descndng order,for Ranking the T-values to get there index
        %indx stores the rank wise the index of
        %selected t score no of voxel (not reak voxel index)
        %indxAll=indx;  %storing the ranked index from 1 to ~4400
        %tempFeat=FeatSel; %stores real voxel index which was ranked as indx
        %taking first 300 from ranked index
        %fetching real voxel index from 1-153594
        
        lookupArray(i,:)=FeatSel(indx(1:300)); %storing the top real 300 voxel index
        clear tempFeat H T i j indx FeatSelNew p a stat;
    end
    [finalGA44_1]=data_svm_300_600Chromosome1(lookupArray,xh,xs,indCV);
    lookupArrayRun1(run,1)={lookupArray};
%     filename=['/home/nk106/Desktop/Indra/fMRI Expmnt/fmri_binaryGA_fbrin_code_10runs/Expt1_postAnalysis_10runs/results2nd10Run/','final60ttestGARun',num2str(run)];
%     save(filename,'finalGA60_1');
    FinalCellAlgoRun1(run,1)={finalGA44_1};
    run
end
save('E:\Research\fMRI\fBRIN_Dataset_analysis\fbirn10+10phase2\Paper2_fBIRN_AGE_nsga\nsgaRun1_linSVM_1.5T\1.5TData60Expt5\data1_linsvm\result1\wholeAlgoRun1_data1.mat','FinalCellAlgoRun1','-v7.3');
save('E:\Research\fMRI\fBRIN_Dataset_analysis\fbirn10+10phase2\Paper2_fBIRN_AGE_nsga\nsgaRun1_linSVM_1.5T\1.5TData60Expt5\data1_linsvm\result1\lookupArrayRun1_data1.mat','lookupArrayRun1','-v7.3');
