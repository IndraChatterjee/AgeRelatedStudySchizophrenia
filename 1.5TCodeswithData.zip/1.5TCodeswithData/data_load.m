% Healthy patent
%dataset1_healthy junior 19-48yrs (14sub)
for i=1:14
    for j=1:2
        file= ['E:\Research\fMRI\fBRIN_Dataset_analysis\fbirn10+10phase2\Paper2_fBIRN_AGE_nsga\contrastH_jun\h',num2str(i),'_r',num2str(j),'_con_0001.img'];
        nii= load_nii(file);
        niiCell{j}=nii.img;
    end
    h{i}=(niiCell{1} + niiCell{2})/2;
    h{i}(isnan(h{i}))=0;
    h{i}=h{i}(:);
    
end
for i=1:14
    xh_jun(i,:)=h{i};
end

%dataset2_healthy senior 59-91yrs (16sub)
for i=15:30
    for j=1:2
        file= ['E:\Research\fMRI\fBRIN_Dataset_analysis\fbirn10+10phase2\Paper2_fBIRN_AGE_nsga\contrastH_sen\h',num2str(i),'_r',num2str(j),'_con_0001.img'];
        nii= load_nii(file);
        niiCell{j}=nii.img;
    end
    h{i}=(niiCell{1} + niiCell{2})/2;
    h{i}(isnan(h{i}))=0;
    h{i}=h{i}(:);
    
end
for i=15:30
    xh_sen(i,:)=h{i};
end

i=1;


%Schizophrenia patient
%dataset1_schizophrenia_junior 24-53yrs (14sub)
for i=1:14
    for j=1:2
        file= ['E:\Research\fMRI\fBRIN_Dataset_analysis\fbirn10+10phase2\Paper2_fBIRN_AGE_nsga\contrastS_jun\s',num2str(i),'_r',num2str(j),'_con_0001.img'];
        nii= load_nii(file);
        niiCell{j}=nii.img;
        
    end
    s{i}=(niiCell{1} + niiCell{2})/2;
    s{i}(isnan(s{i}))=0;
    s{i}=s{i}(:);
    
end
for i=1:14
    xs_jun(i,:)=s{i};
end

%dataset1_schizophrenia_junior 57-87yrs (16sub)
for i=15:30
    for j=1:2
        file= ['E:\Research\fMRI\fBRIN_Dataset_analysis\fbirn10+10phase2\Paper2_fBIRN_AGE_nsga\contrastS_sen\s',num2str(i),'_r',num2str(j),'_con_0001.img'];
        nii= load_nii(file);
        niiCell{j}=nii.img;
        
    end
    s{i}=(niiCell{1} + niiCell{2})/2;
    s{i}(isnan(s{i}))=0;
    s{i}=s{i}(:);
    
end
for i=15:30
    xs_sen(i,:)=s{i};
end

save('dataset1.mat','xh_jun','xs_jun','-v7.3');
save('dataset2.mat','xh_sen','xs_sen','-v7.3');
