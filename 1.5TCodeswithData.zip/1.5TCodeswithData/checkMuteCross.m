function [acc1,newpop,featInd]=checkMuteCross(muteAcc,crossAccNew,Vect300CrossNew,Vect300Mute)
%function to check whether new pop after mutation is better or
%not than the previous crossed vectors respectively
popSize=size(Vect300CrossNew,1);
for i=1:popSize
    if (muteAcc(i,1)>=crossAccNew(i,1) && muteAcc(i,2)<=crossAccNew(i,2)) %for first vector of one pair
        acc1(i,1)=muteAcc(i,1);  %storing the previous acc as new one
        acc1(i,2)=sum(Vect300Mute(i,:));
        newpop(i,:)=Vect300Mute(i,:); %storing the previous vector as new one
    elseif (muteAcc(i,1)<=crossAccNew(i,1) && muteAcc(i,2)<=crossAccNew(i,2)) || (muteAcc(i,1)>=crossAccNew(i,1) && muteAcc(i,2)>=crossAccNew(i,2))
        acc1(i,1)=crossAccNew(i,1); %storing the new crossed acc as new
        acc1(i,2)=sum(Vect300CrossNew(i,:));
        newpop(i,:)=Vect300CrossNew(i,:); %storing the crossed vector as new
    else
        acc1(i,1)=crossAccNew(i,1); %storing the new crossed acc as new
        acc1(i,2)=sum(Vect300CrossNew(i,:));
        newpop(i,:)=Vect300CrossNew(i,:);
    end
    countInd=find(newpop(i,:)==1);
    featInd(i,1)={countInd};
end
end